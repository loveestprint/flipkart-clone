import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database("ecommerce.db");
const JWT_SECRET = "super-secret-key-change-this";

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    name TEXT
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    price REAL,
    image TEXT,
    category TEXT,
    rating REAL,
    stock INTEGER
  );

  CREATE TABLE IF NOT EXISTS cart (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    product_id INTEGER,
    quantity INTEGER,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(product_id) REFERENCES products(id)
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    total REAL,
    status TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    address TEXT,
    payment_method TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    product_id INTEGER,
    quantity INTEGER,
    price REAL,
    FOREIGN KEY(order_id) REFERENCES orders(id),
    FOREIGN KEY(product_id) REFERENCES products(id)
  );
`);

// Seed Products if needed
const targetCount = 175;
const productCount = db.prepare("SELECT COUNT(*) as count FROM products").get() as { count: number };
if (productCount.count < targetCount) {
  const categories = ["Electronics", "Fashion", "Home", "Beauty", "Sports", "Books", "Toys", "Kitchen"];
  const adjectives = ["Premium", "Ultra", "Classic", "Modern", "Essential", "Pro", "Smart", "Eco", "Luxury", "Budget", "Sleek"];
  const nouns = ["Watch", "Headphones", "Shirt", "Lamp", "Cream", "Shoes", "Bottle", "Bag", "Camera", "Phone", "Blender", "Speaker", "Desk"];

  const insertProduct = db.prepare("INSERT INTO products (title, description, price, image, category, rating, stock) VALUES (?, ?, ?, ?, ?, ?, ?)");
  
  const startIdx = productCount.count + 1;
  for (let i = startIdx; i <= targetCount; i++) {
    const category = categories[Math.floor(Math.random() * categories.length)];
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];
    const title = `${adj} ${noun} ${i}`;
    const price = Math.floor(Math.random() * 10000) + 99;
    const rating = (Math.random() * 2 + 3).toFixed(1);
    const stock = Math.floor(Math.random() * 50) + 10;
    const image = `https://picsum.photos/seed/product${i}/400/400`;
    
    insertProduct.run(
      title,
      `High-quality ${title} designed for everyday use. Durable, stylish, and perfect for your ${category.toLowerCase()} needs.`,
      price,
      image,
      category,
      rating,
      stock
    );
  }
  console.log(`Seeded ${targetCount - productCount.count} new products. Total: ${targetCount}`);
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // Auth Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
      next();
    } catch (e) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  // API Routes
  app.post("/api/auth/register", async (req, res) => {
    const { email, password, name } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    try {
      const result = db.prepare("INSERT INTO users (email, password, name) VALUES (?, ?, ?)").run(email, hashedPassword, name);
      const token = jwt.sign({ id: result.lastInsertRowid, email, name }, JWT_SECRET);
      res.json({ token, user: { id: result.lastInsertRowid, email, name } });
    } catch (e) {
      res.status(400).json({ error: "Email already exists" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as any;
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
  });

  app.get("/api/products", (req, res) => {
    const { search, category, sort } = req.query;
    let query = "SELECT * FROM products WHERE 1=1";
    const params: any[] = [];

    if (search) {
      query += " AND (title LIKE ? OR description LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }
    if (category) {
      query += " AND category = ?";
      params.push(category);
    }
    if (sort === "price_asc") query += " ORDER BY price ASC";
    else if (sort === "price_desc") query += " ORDER BY price DESC";
    else if (sort === "rating") query += " ORDER BY rating DESC";

    const products = db.prepare(query).all(...params);
    res.json(products);
  });

  app.get("/api/products/:id", (req, res) => {
    const product = db.prepare("SELECT * FROM products WHERE id = ?").get(req.params.id);
    if (!product) return res.status(404).json({ error: "Product not found" });
    res.json(product);
  });

  app.get("/api/cart", authenticate, (req: any, res) => {
    const items = db.prepare(`
      SELECT c.*, p.title, p.price, p.image 
      FROM cart c 
      JOIN products p ON c.product_id = p.id 
      WHERE c.user_id = ?
    `).all(req.user.id);
    res.json(items);
  });

  app.post("/api/cart", authenticate, (req: any, res) => {
    const { product_id, quantity } = req.body;
    const existing = db.prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?").get(req.user.id, product_id) as any;
    if (existing) {
      db.prepare("UPDATE cart SET quantity = quantity + ? WHERE id = ?").run(quantity, existing.id);
    } else {
      db.prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)").run(req.user.id, product_id, quantity);
    }
    res.json({ success: true });
  });

  app.delete("/api/cart/:id", authenticate, (req: any, res) => {
    db.prepare("DELETE FROM cart WHERE id = ? AND user_id = ?").run(req.params.id, req.user.id);
    res.json({ success: true });
  });

  app.post("/api/orders", authenticate, (req: any, res) => {
    const { address, payment_method, items, total } = req.body;
    const result = db.prepare("INSERT INTO orders (user_id, total, status, address, payment_method) VALUES (?, ?, ?, ?, ?)")
      .run(req.user.id, total, "Processing", address, payment_method);
    
    const orderId = result.lastInsertRowid;
    const insertItem = db.prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
    
    for (const item of items) {
      insertItem.run(orderId, item.product_id, item.quantity, item.price);
    }

    // Clear cart
    db.prepare("DELETE FROM cart WHERE user_id = ?").run(req.user.id);
    
    res.json({ orderId });
  });

  app.get("/api/orders", authenticate, (req: any, res) => {
    const orders = db.prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC").all(req.user.id);
    res.json(orders);
  });

  app.get("/api/orders/:id", authenticate, (req: any, res) => {
    const order = db.prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?").get(req.params.id, req.user.id) as any;
    if (!order) return res.status(404).json({ error: "Order not found" });
    const items = db.prepare(`
      SELECT oi.*, p.title, p.image 
      FROM order_items oi 
      JOIN products p ON oi.product_id = p.id 
      WHERE oi.order_id = ?
    `).all(order.id);
    res.json({ ...order, items });
  });

  // Vite Integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
