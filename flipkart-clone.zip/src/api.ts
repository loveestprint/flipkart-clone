import { Product, User, CartItem, Order } from "./types";

const API_BASE = "/api";

function getHeaders() {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

export const api = {
  async getProducts(params: { search?: string; category?: string; sort?: string } = {}) {
    const query = new URLSearchParams(params as any).toString();
    const res = await fetch(`${API_BASE}/products?${query}`);
    return res.json() as Promise<Product[]>;
  },

  async getProduct(id: string) {
    const res = await fetch(`${API_BASE}/products/${id}`);
    return res.json() as Promise<Product>;
  },

  async login(credentials: any) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(credentials),
    });
    const data = await res.json();
    if (data.token) {
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
    }
    return data;
  },

  async register(data: any) {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    if (result.token) {
      localStorage.setItem("token", result.token);
      localStorage.setItem("user", JSON.stringify(result.user));
    }
    return result;
  },

  logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  },

  async getCart() {
    const res = await fetch(`${API_BASE}/cart`, { headers: getHeaders() });
    return res.json() as Promise<CartItem[]>;
  },

  async addToCart(product_id: number, quantity: number = 1) {
    const res = await fetch(`${API_BASE}/cart`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ product_id, quantity }),
    });
    return res.json();
  },

  async removeFromCart(id: number) {
    const res = await fetch(`${API_BASE}/cart/${id}`, {
      method: "DELETE",
      headers: getHeaders(),
    });
    return res.json();
  },

  async createOrder(orderData: any) {
    const res = await fetch(`${API_BASE}/orders`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(orderData),
    });
    return res.json();
  },

  async getOrders() {
    const res = await fetch(`${API_BASE}/orders`, { headers: getHeaders() });
    return res.json() as Promise<Order[]>;
  },

  async getOrder(id: string) {
    const res = await fetch(`${API_BASE}/orders/${id}`, { headers: getHeaders() });
    return res.json() as Promise<Order>;
  },
};
