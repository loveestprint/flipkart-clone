import React, { createContext, useContext, useState, useEffect } from "react";
import { User, CartItem } from "./types";
import { api } from "./api";

interface AuthContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  cart: CartItem[];
  refreshCart: () => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);

  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    if (user) {
      refreshCart();
    } else {
      setCart([]);
    }
  }, [user]);

  const refreshCart = async () => {
    if (!user) return;
    try {
      const items = await api.getCart();
      setCart(items);
    } catch (e) {
      console.error("Failed to fetch cart", e);
    }
  };

  const logout = () => {
    api.logout();
    setUser(null);
    setCart([]);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, cart, refreshCart, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};
