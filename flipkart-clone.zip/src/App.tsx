import React, { useState, useEffect } from "react";
import { Search, ShoppingCart, User as UserIcon, LogOut, Menu, X, ChevronRight, Star } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useAuth } from "./AuthContext";
import { api } from "./api";
import { Product, CartItem, Order, cn } from "./types";

// --- Components ---

const Navbar = ({ onSearch, onOpenAuth, onNavigate }: { onSearch: (q: string) => void, onOpenAuth: () => void, onNavigate: (page: string) => void }) => {
  const { user, cart, logout } = useAuth();
  const [query, setQuery] = useState("");

  return (
    <nav className="bg-[#2874f0] text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center gap-4 md:gap-8">
        {/* Logo */}
        <div className="cursor-pointer flex flex-col items-start" onClick={() => onNavigate("home")}>
          <span className="text-xl font-bold italic leading-none">Flipkart</span>
          <span className="text-[10px] italic text-yellow-400 font-bold flex items-center">
            Explore <span className="text-white mx-0.5">Plus</span>
            <Star className="w-2 h-2 fill-yellow-400" />
          </span>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-xl relative">
          <input
            type="text"
            placeholder="Search for products, brands and more"
            className="w-full py-2 px-4 pr-10 rounded-sm text-black focus:outline-none text-sm"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && onSearch(query)}
          />
          <Search className="absolute right-3 top-2 text-[#2874f0] w-5 h-5 cursor-pointer" onClick={() => onSearch(query)} />
        </div>

        {/* Actions */}
        <div className="hidden md:flex items-center gap-8 font-semibold text-sm">
          {user ? (
            <div className="group relative cursor-pointer">
              <span className="flex items-center gap-1">
                {user.name} <ChevronRight className="w-4 h-4 rotate-90" />
              </span>
              <div className="absolute top-full right-0 bg-white text-black shadow-xl rounded-sm py-2 w-48 hidden group-hover:block border border-gray-100">
                <div className="px-4 py-2 hover:bg-gray-50 flex items-center gap-2" onClick={() => onNavigate("orders")}>
                  <UserIcon className="w-4 h-4 text-[#2874f0]" /> My Profile
                </div>
                <div className="px-4 py-2 hover:bg-gray-50 flex items-center gap-2" onClick={() => onNavigate("orders")}>
                  <ShoppingCart className="w-4 h-4 text-[#2874f0]" /> Orders
                </div>
                <div className="px-4 py-2 hover:bg-gray-50 flex items-center gap-2 border-t" onClick={logout}>
                  <LogOut className="w-4 h-4 text-[#2874f0]" /> Logout
                </div>
              </div>
            </div>
          ) : (
            <button onClick={onOpenAuth} className="bg-white text-[#2874f0] px-8 py-1 rounded-sm font-bold">Login</button>
          )}
          
          <div className="cursor-pointer flex items-center gap-2" onClick={() => onNavigate("cart")}>
            <div className="relative">
              <ShoppingCart className="w-5 h-5" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
                  {cart.reduce((acc, item) => acc + item.quantity, 0)}
                </span>
              )}
            </div>
            Cart
          </div>
        </div>
      </div>
    </nav>
  );
};

const ProductCard: React.FC<{ product: Product, onClick: () => void }> = ({ product, onClick }) => {
  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      className="bg-white p-4 rounded-sm border border-transparent hover:border-gray-100 hover:shadow-lg cursor-pointer flex flex-col h-full"
      onClick={onClick}
    >
      <div className="h-48 flex items-center justify-center mb-4 overflow-hidden">
        <img src={product.image} alt={product.title} className="max-h-full object-contain" referrerPolicy="no-referrer" />
      </div>
      <h3 className="text-sm font-medium line-clamp-2 mb-1">{product.title}</h3>
      <div className="flex items-center gap-2 mb-2">
        <span className="bg-green-600 text-white text-[10px] px-1.5 py-0.5 rounded-sm flex items-center gap-0.5 font-bold">
          {product.rating} <Star className="w-2 h-2 fill-white" />
        </span>
        <span className="text-gray-400 text-xs font-medium">(1,234)</span>
      </div>
      <div className="mt-auto">
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold">₹{product.price.toLocaleString()}</span>
          <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png" alt="assured" className="h-4" referrerPolicy="no-referrer" />
        </div>
        <p className="text-xs text-green-600 font-bold mt-1">Free delivery</p>
      </div>
    </motion.div>
  );
};

const AuthModal = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const { setUser } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = isLogin 
        ? await api.login({ email, password })
        : await api.register({ email, password, name });
      
      if (res.user) {
        setUser(res.user);
        onClose();
      } else {
        alert(res.error || "Something went wrong");
      }
    } catch (e) {
      alert("Auth failed");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white w-full max-w-3xl flex rounded-sm overflow-hidden h-[500px]"
      >
        <div className="w-2/5 bg-[#2874f0] p-10 text-white flex flex-col">
          <h2 className="text-3xl font-bold mb-4">{isLogin ? "Login" : "Looks like you're new here!"}</h2>
          <p className="text-lg opacity-80">{isLogin ? "Get access to your Orders, Wishlist and Recommendations" : "Sign up with your email to get started"}</p>
          <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/login_img_c4a81e.png" alt="login" className="mt-auto" referrerPolicy="no-referrer" />
        </div>
        <div className="flex-1 p-10 relative">
          <button onClick={onClose} className="absolute top-4 right-4 text-gray-400"><X /></button>
          <form onSubmit={handleSubmit} className="space-y-6 mt-10">
            {!isLogin && (
              <input 
                type="text" 
                placeholder="Enter Name" 
                className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-[#2874f0]" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            )}
            <input 
              type="email" 
              placeholder="Enter Email" 
              className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-[#2874f0]" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input 
              type="password" 
              placeholder="Enter Password" 
              className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-[#2874f0]" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <p className="text-[10px] text-gray-400">By continuing, you agree to Flipkart's Terms of Use and Privacy Policy.</p>
            <button type="submit" className="w-full bg-[#fb641b] text-white py-3 font-bold rounded-sm shadow-md">
              {isLogin ? "Login" : "Continue"}
            </button>
            <button type="button" onClick={() => setIsLogin(!isLogin)} className="w-full text-[#2874f0] font-bold text-sm mt-auto">
              {isLogin ? "New to Flipkart? Create an account" : "Existing User? Log in"}
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

// --- Pages ---

const HomePage = ({ onProductClick, categoryFilter, searchFilter }: { onProductClick: (p: Product) => void, categoryFilter?: string, searchFilter?: string }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const categories = ["Electronics", "Fashion", "Home", "Beauty", "Sports", "Books"];

  useEffect(() => {
    api.getProducts({ category: categoryFilter, search: searchFilter }).then(data => {
      setProducts(data);
      setLoading(false);
    });
  }, [categoryFilter, searchFilter]);

  if (loading) return <div className="p-10 text-center">Loading...</div>;

  return (
    <div className="bg-gray-100 min-h-screen pb-10">
      {/* Category Bar */}
      {!searchFilter && (
        <div className="bg-white shadow-sm mb-4">
          <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between overflow-x-auto gap-8">
            {categories.map(cat => (
              <div 
                key={cat} 
                className={cn(
                  "flex flex-col items-center gap-2 cursor-pointer group min-w-fit",
                  categoryFilter === cat && "text-[#2874f0]"
                )}
                onClick={() => window.dispatchEvent(new CustomEvent("filter-category", { detail: cat }))}
              >
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <img src={`https://picsum.photos/seed/${cat}/100/100`} alt={cat} className="w-12 h-12 object-contain rounded-full" referrerPolicy="no-referrer" />
                </div>
                <span className="text-sm font-bold">{cat}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Hero Banner (Only on home without filters) */}
      {!categoryFilter && !searchFilter && (
        <div className="max-w-7xl mx-auto px-4 mb-6">
          <div className="h-64 bg-[#2874f0] rounded-sm overflow-hidden relative">
            <img src="https://picsum.photos/seed/banner/1200/400" alt="banner" className="w-full h-full object-cover opacity-80" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 flex flex-col justify-center px-12 text-white">
              <h2 className="text-4xl font-bold mb-2">Big Saving Days</h2>
              <p className="text-xl mb-4">Up to 80% Off on Top Brands</p>
              <button className="bg-white text-[#2874f0] px-8 py-2 font-bold rounded-sm w-fit">Shop Now</button>
            </div>
          </div>
        </div>
      )}

      {/* Product Grid */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="bg-white p-4 rounded-sm shadow-sm mb-6">
          <div className="flex items-center justify-between mb-6 border-b pb-4">
            <h2 className="text-xl font-bold">
              {searchFilter ? `Results for "${searchFilter}"` : categoryFilter ? `${categoryFilter} Products` : "Best of Electronics"}
            </h2>
            {!searchFilter && !categoryFilter && (
              <button className="bg-[#2874f0] text-white px-4 py-1.5 rounded-sm text-sm font-bold">VIEW ALL</button>
            )}
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {products.map(p => (
              <ProductCard key={p.id} product={p} onClick={() => onProductClick(p)} />
            ))}
          </div>
          {products.length === 0 && (
            <div className="py-20 text-center text-gray-400">No products found.</div>
          )}
        </div>
      </div>
    </div>
  );
};

const ProductDetailPage = ({ product, onAddToCart }: { product: Product, onAddToCart: (p: Product) => void }) => {
  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col md:flex-row gap-10">
        {/* Left: Image & Actions */}
        <div className="w-full md:w-2/5 sticky top-24 h-fit">
          <div className="border p-4 mb-4 flex items-center justify-center h-[400px]">
            <img src={product.image} alt={product.title} className="max-h-full object-contain" referrerPolicy="no-referrer" />
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => onAddToCart(product)}
              className="flex-1 bg-[#ff9f00] text-white py-4 font-bold rounded-sm flex items-center justify-center gap-2 shadow-md"
            >
              <ShoppingCart className="w-5 h-5" /> ADD TO CART
            </button>
            <button className="flex-1 bg-[#fb641b] text-white py-4 font-bold rounded-sm flex items-center justify-center gap-2 shadow-md">
              BUY NOW
            </button>
          </div>
        </div>

        {/* Right: Details */}
        <div className="flex-1">
          <nav className="text-xs text-gray-400 flex items-center gap-1 mb-2">
            Home <ChevronRight className="w-3 h-3" /> {product.category} <ChevronRight className="w-3 h-3" /> {product.title}
          </nav>
          <h1 className="text-xl font-medium mb-2">{product.title}</h1>
          <div className="flex items-center gap-2 mb-4">
            <span className="bg-green-600 text-white text-xs px-2 py-0.5 rounded-sm flex items-center gap-1 font-bold">
              {product.rating} <Star className="w-3 h-3 fill-white" />
            </span>
            <span className="text-gray-400 font-bold text-sm">1,234 Ratings & 567 Reviews</span>
            <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png" alt="assured" className="h-5" referrerPolicy="no-referrer" />
          </div>
          <div className="flex items-baseline gap-3 mb-6">
            <span className="text-3xl font-bold">₹{product.price.toLocaleString()}</span>
            <span className="text-gray-400 line-through">₹{(product.price * 1.5).toFixed(0)}</span>
            <span className="text-green-600 font-bold">33% off</span>
          </div>

          <div className="space-y-4 mb-8">
            <h3 className="font-bold">Available offers</h3>
            <div className="flex items-start gap-2 text-sm">
              <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/offer_94e974.png" alt="offer" className="w-4 mt-1" referrerPolicy="no-referrer" />
              <span><b>Bank Offer</b> 10% off on SBI Credit Card, up to ₹1,500. T&C</span>
            </div>
            <div className="flex items-start gap-2 text-sm">
              <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/offer_94e974.png" alt="offer" className="w-4 mt-1" referrerPolicy="no-referrer" />
              <span><b>Bank Offer</b> 5% Cashback on Flipkart Axis Bank Card. T&C</span>
            </div>
          </div>

          <div className="border rounded-sm p-4 space-y-4">
            <div className="flex gap-10">
              <span className="text-gray-400 font-bold w-20">Delivery</span>
              <div>
                <div className="flex items-center gap-2 border-b border-[#2874f0] pb-1 w-fit mb-1">
                  <span className="font-bold">Delivery by 10 Mar, Tuesday | </span>
                  <span className="text-green-600 font-bold">Free</span>
                </div>
                <p className="text-xs text-gray-400">If ordered before 11:59 PM today</p>
              </div>
            </div>
            <div className="flex gap-10">
              <span className="text-gray-400 font-bold w-20">Description</span>
              <p className="text-sm leading-relaxed">{product.description}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const CartPage = ({ onCheckout }: { onCheckout: () => void }) => {
  const { cart, refreshCart } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleRemove = async (id: number) => {
    await api.removeFromCart(id);
    refreshCart();
  };

  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  if (cart.length === 0) {
    return (
      <div className="bg-gray-100 min-h-screen flex items-center justify-center p-4">
        <div className="bg-white p-10 rounded-sm shadow-sm text-center max-w-md w-full">
          <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/my_cart_empty_535668.png" alt="empty" className="w-48 mx-auto mb-6" referrerPolicy="no-referrer" />
          <h2 className="text-xl font-bold mb-2">Your cart is empty!</h2>
          <p className="text-sm text-gray-400 mb-6">Add items to it now.</p>
          <button className="bg-[#2874f0] text-white px-10 py-2.5 font-bold rounded-sm shadow-md">Shop Now</button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-100 min-h-screen py-6">
      <div className="max-w-7xl mx-auto px-4 flex flex-col lg:flex-row gap-4">
        {/* Cart Items */}
        <div className="flex-1 space-y-4">
          <div className="bg-white p-4 rounded-sm shadow-sm flex justify-between items-center">
            <h2 className="text-lg font-bold">My Cart ({cart.length})</h2>
            <div className="flex items-center gap-2 text-sm">
              <span>Deliver to: <b>Mumbai - 400001</b></span>
              <button className="text-[#2874f0] font-bold border px-3 py-1 rounded-sm">Change</button>
            </div>
          </div>

          {cart.map(item => (
            <div key={item.id} className="bg-white p-6 rounded-sm shadow-sm flex gap-6">
              <div className="w-24 h-24 flex items-center justify-center">
                <img src={item.image} alt={item.title} className="max-h-full object-contain" referrerPolicy="no-referrer" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium line-clamp-1 mb-1">{item.title}</h3>
                <p className="text-xs text-gray-400 mb-4">Seller: RetailNet</p>
                <div className="flex items-center gap-3">
                  <span className="text-lg font-bold">₹{item.price.toLocaleString()}</span>
                  <span className="text-green-600 text-sm font-bold">2 offers applied</span>
                </div>
                <div className="mt-6 flex gap-6">
                  <button onClick={() => handleRemove(item.id)} className="font-bold hover:text-[#2874f0]">REMOVE</button>
                  <button className="font-bold hover:text-[#2874f0]">SAVE FOR LATER</button>
                </div>
              </div>
              <div className="text-sm">
                Delivery by Tue Mar 10 | <span className="text-green-600">Free</span>
              </div>
            </div>
          ))}

          <div className="bg-white p-4 rounded-sm shadow-sm flex justify-end sticky bottom-0 border-t">
            <button 
              onClick={onCheckout}
              className="bg-[#fb641b] text-white px-16 py-3.5 font-bold rounded-sm shadow-lg"
            >
              PLACE ORDER
            </button>
          </div>
        </div>

        {/* Price Details */}
        <div className="w-full lg:w-96 sticky top-24 h-fit">
          <div className="bg-white rounded-sm shadow-sm">
            <h3 className="p-4 text-gray-400 font-bold border-b">PRICE DETAILS</h3>
            <div className="p-4 space-y-4 text-sm">
              <div className="flex justify-between">
                <span>Price ({cart.length} items)</span>
                <span>₹{total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Discount</span>
                <span className="text-green-600">- ₹{(total * 0.1).toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Charges</span>
                <span className="text-green-600">FREE</span>
              </div>
              <div className="flex justify-between text-lg font-bold border-t border-dashed pt-4">
                <span>Total Amount</span>
                <span>₹{(total * 0.9).toLocaleString()}</span>
              </div>
              <p className="text-green-600 font-bold pt-2">You will save ₹{(total * 0.1).toFixed(0)} on this order</p>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-gray-400 text-sm font-bold p-4">
            <Star className="w-4 h-4" /> Safe and Secure Payments. Easy returns. 100% Authentic products.
          </div>
        </div>
      </div>
    </div>
  );
};

const OrderTrackingPage = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getOrders().then(data => {
      setOrders(data);
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="p-10 text-center">Loading...</div>;

  return (
    <div className="bg-gray-100 min-h-screen py-6">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-xl font-bold mb-6">My Orders</h2>
        <div className="space-y-4">
          {orders.map(order => (
            <div key={order.id} className="bg-white p-6 rounded-sm shadow-sm flex flex-col md:flex-row gap-6 items-center">
              <div className="w-20 h-20 bg-gray-50 rounded-sm flex items-center justify-center">
                <ShoppingCart className="w-8 h-8 text-gray-300" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold">Order ID: #{order.id}</h3>
                <p className="text-sm text-gray-400">Placed on {new Date(order.created_at).toLocaleDateString()}</p>
                <p className="text-sm mt-2">Total: <b>₹{order.total.toLocaleString()}</b></p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span className="font-bold text-sm">{order.status}</span>
              </div>
              <button className="text-[#2874f0] font-bold text-sm flex items-center gap-1">
                TRACK ORDER <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          ))}
          {orders.length === 0 && (
            <div className="bg-white p-10 text-center rounded-sm shadow-sm">
              <p className="text-gray-400">No orders found.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<string | undefined>();
  const [searchFilter, setSearchFilter] = useState<string | undefined>();
  const { user, refreshCart } = useAuth();

  useEffect(() => {
    const handleFilter = (e: any) => {
      setCategoryFilter(e.detail);
      setSearchFilter(undefined);
      setCurrentPage("home");
    };
    window.addEventListener("filter-category", handleFilter);
    return () => window.removeEventListener("filter-category", handleFilter);
  }, []);

  const handleSearch = (q: string) => {
    setSearchFilter(q);
    setCategoryFilter(undefined);
    setCurrentPage("home");
  };

  const handleProductClick = (p: Product) => {
    setSelectedProduct(p);
    setCurrentPage("detail");
    window.scrollTo(0, 0);
  };

  const handleAddToCart = async (p: Product) => {
    if (!user) {
      setIsAuthOpen(true);
      return;
    }
    await api.addToCart(p.id, 1);
    refreshCart();
    alert("Added to cart!");
  };

  const handleCheckout = async () => {
    if (!user) {
      setIsAuthOpen(true);
      return;
    }
    // Simple simulated checkout
    const total = 10000; // Mock total
    await api.createOrder({
      address: "123, Sample Street, Mumbai",
      payment_method: "Credit Card",
      items: [], // In real app, pass cart items
      total
    });
    alert("Order placed successfully!");
    setCurrentPage("orders");
  };

  return (
    <div className="font-sans text-[#212121]">
      <Navbar 
        onSearch={handleSearch} 
        onOpenAuth={() => setIsAuthOpen(true)} 
        onNavigate={(p) => {
          setCurrentPage(p);
          setCategoryFilter(undefined);
          setSearchFilter(undefined);
          window.scrollTo(0, 0);
        }} 
      />
      
      <main>
        {currentPage === "home" && (
          <HomePage 
            onProductClick={handleProductClick} 
            categoryFilter={categoryFilter}
            searchFilter={searchFilter}
          />
        )}
        {currentPage === "detail" && selectedProduct && (
          <ProductDetailPage product={selectedProduct} onAddToCart={handleAddToCart} />
        )}
        {currentPage === "cart" && <CartPage onCheckout={handleCheckout} />}
        {currentPage === "orders" && <OrderTrackingPage />}
      </main>

      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />

      {/* Footer */}
      <footer className="bg-[#172337] text-white py-12 mt-10">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 text-xs">
          <div className="space-y-2">
            <h4 className="text-gray-400 mb-4 uppercase">About</h4>
            <p>Contact Us</p>
            <p>About Us</p>
            <p>Careers</p>
            <p>Flipkart Stories</p>
          </div>
          <div className="space-y-2">
            <h4 className="text-gray-400 mb-4 uppercase">Help</h4>
            <p>Payments</p>
            <p>Shipping</p>
            <p>Cancellation</p>
            <p>Returns</p>
          </div>
          <div className="space-y-2">
            <h4 className="text-gray-400 mb-4 uppercase">Policy</h4>
            <p>Return Policy</p>
            <p>Terms Of Use</p>
            <p>Security</p>
            <p>Privacy</p>
          </div>
          <div className="space-y-2">
            <h4 className="text-gray-400 mb-4 uppercase">Social</h4>
            <p>Facebook</p>
            <p>Twitter</p>
            <p>YouTube</p>
          </div>
          <div className="col-span-2 border-l border-gray-700 pl-8 space-y-4">
            <h4 className="text-gray-400 uppercase">Mail Us:</h4>
            <p className="text-gray-300 leading-relaxed">
              Flipkart Internet Private Limited,<br />
              Buildings Alyssa, Begonia &<br />
              Clove Embassy Tech Village,<br />
              Outer Ring Road, Devarabeesanahalli Village,<br />
              Bengaluru, 560103, Karnataka, India
            </p>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-gray-700 flex flex-wrap justify-between gap-4 text-sm">
          <div className="flex gap-8">
            <span className="flex items-center gap-2"><ShoppingCart className="w-4 h-4 text-yellow-400" /> Become a Seller</span>
            <span className="flex items-center gap-2"><Star className="w-4 h-4 text-yellow-400" /> Advertise</span>
            <span className="flex items-center gap-2"><Star className="w-4 h-4 text-yellow-400" /> Gift Cards</span>
            <span className="flex items-center gap-2"><Star className="w-4 h-4 text-yellow-400" /> Help Center</span>
          </div>
          <p>© 2007-2025 Flipkart.com</p>
          <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/payment-method_69e7bc.svg" alt="payments" referrerPolicy="no-referrer" />
        </div>
      </footer>
    </div>
  );
}
